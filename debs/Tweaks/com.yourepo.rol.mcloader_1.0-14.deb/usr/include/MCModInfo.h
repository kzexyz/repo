#import <Preferences/Preferences.h>
#import <Preferences/PSSpecifier.h>
#import <Foundation/Foundation.h>
#import <substrate.h>

@interface MCModInfo : NSObject
+(float)floatValueForPreferences:(NSString *)preferences key:(NSString *)key;
+(int)intValueForPreferences:(NSString *)preferences key:(NSString *)key;
+(BOOL)boolValueForPreferences:(NSString *)preferences key:(NSString *)key;
+(NSString *)stringValueForPreferences:(NSString *)preferences key:(NSString *)key;
@end
